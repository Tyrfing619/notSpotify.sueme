/*
Project Changes
Jordan - Created SearchActivity and linked the search button to the SearchActivity
 */

package com.example.notspotify_phase34_v15;

import android.content.Intent;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;

public class MainActivity extends AppCompatActivity {
    static MediaPlayer musicPlayer;
    ImageButton pauseplayIcon;
    SeekBar seekBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView songName = findViewById(R.id.songName);
        TextView artistName = findViewById(R.id.artistName);
        TextView albumName = findViewById(R.id.albumName);

        musicPlayer = MediaPlayer.create(this, R.raw.music1);                                // Local Play
                                                                                                    // raw is the folder within the res folder, the music1 describes the name of the mp3 file
        pauseplayIcon = findViewById(R.id.pause_playButton);
        pauseplayIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {                                                           // WIP pause mechanic
                if (!MainActivity.musicPlayer.isPlaying()) {
                    pauseplayIcon.setImageResource(android.R.drawable.ic_media_pause);              // continue playing
                    songName.setText(R.string.currentSong);
                    artistName.setText(R.string.currentArtist);
                    albumName.setText(R.string.currentAlbum);
                    MainActivity.musicPlayer.start();                                               // plays
                } else {
                    pauseplayIcon.setImageResource(android.R.drawable.ic_media_play);               // pauses
                    songName.setText(R.string.paused);
                    artistName.setText("");
                    albumName.setText("");
                    MainActivity.musicPlayer.pause();
                }
            }
        });

        final TextView seekBarHint = findViewById(R.id.textView);
        seekBar = findViewById(R.id.seekBar);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int x = (int) Math.ceil(progress / 1000f);
                if (x == 0 && musicPlayer != null && !musicPlayer.isPlaying()) {
                    clearMusicPlayer();
                    pauseplayIcon.setImageResource(android.R.drawable.ic_media_play);
                    MainActivity.this.seekBar.setProgress(0);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                seekBarHint.setVisibility(View.VISIBLE);
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if (musicPlayer != null && musicPlayer.isPlaying()) {
                    musicPlayer.seekTo((seekBar.getProgress()));
                }
            }
        });
    }

    public void switchToSearchActivity(View view) {
            Intent intent = new Intent(this, SearchActivity.class);
            startActivity(intent);
    }

    /*public void playSong() {
        try {
            if (musicPlayer != null && musicPlayer.isPlaying()) {
                clearMusicPlayer();
                seekBar.setProgress(0);
                pauseplayIcon.setImageResource(android.R.drawable.ic_media_pause);
            }
            if (!musicPlayer.isPlaying()) {
                if(musicPlayer == null) {
                    musicPlayer = new MediaPlayer();
                }
            }
        }
    }*/

    public void run() {

    }

    private void clearMusicPlayer() {
        musicPlayer.stop();
        musicPlayer.release();
        musicPlayer = null;
    }
    protected void onDestroy() {
        MainActivity.super.onDestroy();
        clearMusicPlayer();
    }

}