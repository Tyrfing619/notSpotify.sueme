/*
Project Changes/Notes:
    Michael, Stephen    - deleted musicControl, userInput activities to be merged into the musicPlayer and searchScreen respectively
                        - started attempts on local file play
                        - "functioning" pause/play button
                        - Playing around with the functions of XML, still learning
 */

package com.example.notspotify_phase3_4_v1;

import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.Scanner;

public class MainActivity extends AppCompatActivity {
    public static MediaPlayer musicPlayer;
    public ImageButton pauseplayIcon;
    public static String songName;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        musicPlayer = new MediaPlayer();
        musicPlayer.setAudioAttributes(
                new AudioAttributes.Builder().setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
        );

        try{
            MainActivity.musicPlayer.setDataSource(//Set data source here, );               //Work on this ASAP

        } catch (IOException e) {
            e.printStacktrace();
        }


        pauseplayIcon = findViewById(R.id.pause_playButton);
        TextView songName = findViewById(R.id.songName);
        pauseplayIcon.setOnClickListener(v -> {
            if(!MainActivity.musicPlayer.isPlaying()) {
                pauseplayIcon.setImageResource(android.R.drawable.ic_media_pause);          //continue playing
                songName.setText(R.string.currentSong);
                MainActivity.musicPlayer.start();
            }
            else {
                pauseplayIcon.setImageResource(android.R.drawable.ic_media_play);
                songName.setText(R.string.paused);
                MainActivity.musicPlayer.pause();
            }
        });
    }



}