package com.example.notspotify_phase3_4_v1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import java.util.Scanner;

public class MainActivity2 extends AppCompatActivity {
    public static String input;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);


        //Search bar
        Scanner input = new Scanner(System.in);
        System.out.print("Enter song name: ");
        songName = input.nextLine();
        input.close();

        //search algorithm
        //is input known to MainActivity1?

    }
}