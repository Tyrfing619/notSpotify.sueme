package com.example.notspotify_phase1_2_v2;


public class loadMusic extends userInput{

    public static void main(String[] args) {

    }
}
