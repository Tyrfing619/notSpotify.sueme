package com.example.notspotify_phase1_2_v2;

import java.util.Scanner;               //user input

public class userInput extends MainActivity{
    public static String songName;

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter song name: ");
        songName = input.nextLine();
        input.close();
    }
}
