package com.example.notspotify_phase1_2_v2;

public class musicControl extends MainActivity {
    public static void main(String[] args) {
        //WIP pause mechanic
        if(musicPlayer.isPlaying()) {               //we will need to implement the MediaPlayer API!!!
            musicPlayer.pause();
        }
        else{
            musicPlayer.start();
        }
    }
}
