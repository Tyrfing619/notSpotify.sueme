/*
Project Changes/Notes:
        - starting to fine-tune our base code (C++ and HTML ver) into an understandable Java form
        - started to fiddle around with XML and the buttons for the screen, as well as a TextView
 */

package com.example.notspotify_phase1_2_v2;

import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    public static MediaPlayer musicPlayer;
    private static int testTry = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageButton pauseplayIcon = findViewById(R.id.pause_playButton);
        TextView songName = findViewById(R.id.songName);

        pauseplayIcon.setOnClickListener(v -> {
            if(/*playIcon.getDrawable() == getResources().getDrawable(android.R.drawable.ic_media_pause)*/ testTry % 2 == 0) {
                pauseplayIcon.setImageResource(android.R.drawable.ic_media_pause);
                songName.setText(R.string.currentSong);
            }
            else {
                pauseplayIcon.setImageResource(android.R.drawable.ic_media_play);
                songName.setText(R.string.paused);
            }
            testTry++;
        });

        musicPlayer = new MediaPlayer();
        musicPlayer.setAudioAttributes(
                new AudioAttributes.Builder().setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
        );

    }
}