import java.util.Scanner;	//user input

const song = document.getElementById('song');			//Is in chronological, closed loop 
// song is functional relationship
const cover = document.getElementById('cover');
const title = document.getElementById('title');
const artist = document.getElementById('artist');
//temp vv
const genre = document.getElementById('genre');
//temp ^^

const tracks = [
    {
        title: 'Cant Help Falling in Love',
        artist: 'Elvis Presley',
        coverPath: 'cover1.jpg',
        songPath: 'music1.mp3',
        duration: '3:00',
    },
    {
        title: 'Cant Help Falling in Love',
        artist: 'Elvis Presley',
        coverPath: 'cover1.jpg',
        songPath: 'music1.mp3',
        duration: '3:00',
    }
];

public class userInput {								//Will be implemented to get remote WIP
	public String name;
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter song name: ");
		name = in.nextLine();
	}
}

public class loadMusic{
	public loadMusic() {		//Consider the load in storing privately (libraries in the cookies) later
		// Load
		loadSong(tracks[trackIndex]);
		//^^One day may be an inner function WIP

		// Load selected track
		function loadSong(track) {
			cover.src = track.coverPath;
			song.src = track.songPath;
			title.textContent = track.title;
			artist.textContent = track.artist;
			duration.textContent = track.duration;
		}
	}
	public String toString(const input) {
		return input;
	}
	public static void main(String [] args) {
		loadMusic testRun = new loadMusic();
	}	//^^testRun is not finalized name for this
}

/*
public class fileDetails {
	public String track;
	public String songCreator;
	public String album;
	publis String genre;
	
	public public fileDetails() {		//Consider the load in storing privately (libraries in the cookies) later
		track = testRun.toString(song.src);
		songCreator = testRun.toString(artist.textContent);
		album = testRun.toString(artist.textContent);
		//genre = testRun.toString(genre)		temporary, may be used (possible bonus)
		if(track == "") {
			System.out.println("Error: input is empty");
			System.exit(0);
		}
	}
	public static void main(String [] args) {
		fileDetails currentSong = new fileDetails();
	}
}
*/

public class playMusic{
	private 
	public static void main(String [] args) {
	}
}

public class pauseMusic{
	public static void main(String [] args) {
	//WIP pause mechanic
		boolean is_paused(string input) {
			boolean flag = false;
			if(//pause button on UI (through XML) is pressed) {
				flag = true;
			}
			return flag;
		}
	}
}