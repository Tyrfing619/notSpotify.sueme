package com.example.notspotify_phase1_2;

import java.util.Scanner;               //user input

public class userInput {
    public String name;

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter song name: ");
        name = input.nextLine();
        input.close();
    }
}