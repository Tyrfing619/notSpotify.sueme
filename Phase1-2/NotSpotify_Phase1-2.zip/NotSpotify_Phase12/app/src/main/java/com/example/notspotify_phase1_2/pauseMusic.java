package com.example.notspotify_phase1_2;

import android.media.MediaPlayer;

public class pauseMusic /*extends userInput*/ {

    public static void main(String [] args) {
        /*WIP pause mechanic
        if(musicPlayer.isPlaying()) {               //we will need to implement the MusicPlayer API!!!
            musicPlayer.pause();
        }
        else{
            musicPlayer.start();
        }*/
    }
}
