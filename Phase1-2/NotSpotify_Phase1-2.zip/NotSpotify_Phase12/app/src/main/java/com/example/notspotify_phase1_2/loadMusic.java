package com.example.notspotify_phase1_2;

public class loadMusic /*extends userInput*/ {
    /*public static song= document.getElementById('song');			//Is in chronological, closed loop          //fix the const, const does not work.  Refer to static methods etc.etc.
    // song is functional relationship                                                                      //Ask Wilson what these document stuff works, will we have to import an object?
    public static cover = document.getElementById('cover');
    public static title = document.getElementById('title');
    public static artist = document.getElementById('artist');
    //temp vv
    public static genre = document.getElementById('genre');                                         //Current loadMusic is not working, push back development of this whilst working with system UI
    //temp ^^
    public static tracks = [
        {
            title: 'Cant Help Falling in Love',
                artist: 'Elvis Presley',
            coverPath: 'cover1.jpg',
            songPath: 'music1.mp3',
            duration: '3:00',
        },
        {
            title: 'Cant Help Falling in Love',
                artist: 'Elvis Presley',
            coverPath: 'cover1.jpg',
            songPath: 'music1.mp3',
            duration: '3:00',
        }
    ];


    public loadMusic() {		//Consider the load in storing privately (libraries in the cookies) later
            // Load
        //loadSong(tracks[trackIndex]);
            //^^One day may be an inner function WIP

        // Load selected track
        loadMusic(track) {                      //What is this function? Where does track come from
            cover.src = track.coverPath;
            song.src = track.songPath;
            title.textContent = track.title;
            artist.textContent = track.artist;
            duration.textContent = track.duration;
		}
    }

    public static void main(String [] args) {
        loadMusic testRun = new loadMusic(name);
    }	//^^testRun is not finalized name for this
    */
}
