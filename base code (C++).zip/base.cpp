#include <iostream>
using namespace std;

class GrabMusic
{
    private:
        string musicfilename;
        string track;
        string title;
    public:
        GrabMusic(string song, string artist)
        {
            track = song;
            title = artist;
        }

        void musicfile(string input)
        {
            if (input == "")
                cout << "Error: input is empty" << endl;
        }
};

class PlayMusic
{
    public:
        PlayMusic() {}

        bool is_playing(string input)
        {
            bool flag = false;
            if (/*what condition?*/)
                flag = true;
            return flag;
        }
};

class PauseMusic
{
    public:
        PauseMusic() {}

        bool is_paused(string intput)
        {
            bool flag = false;
            if (/*what condition?*/)
                flag = true;
            return flag;
        }
};

int main()
{
    // Testing phase
    string input = "Never Gonna Give You Up";
    GrabMusic gm;
    gm.musicfile(input);

    return 0;
}