/*
Project Changes
Stephen - pathway between SearchActivity to MainActivity, sending the .mp file path and miscellaneous info to the music player.

 */

package com.example.notspotify_phase5_v2;

import android.content.Intent;
import android.media.MediaPlayer;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.TextView;
import android.annotation.SuppressLint;
import android.os.Handler;
import android.os.Message;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    static MediaPlayer musicPlayer;
    ImageButton pausePlayIcon;
    ImageButton fastForward;
    ImageButton previous;
    TextView songName;
    TextView artistName;
    TextView albumName;
    TextView curTime;
    TextView totTime;
    SeekBar seekBar;

    ArrayList<String> songList;
    Intent songData;
    Bundle bundle;
    int position;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        songName = findViewById(R.id.songName);
        artistName = findViewById(R.id.artistName);
        albumName = findViewById(R.id.albumName);
        pausePlayIcon = findViewById(R.id.pause_playButton);
        seekBar = findViewById(R.id.seekBar);
        curTime = findViewById(R.id.curTime);
        totTime = findViewById(R.id.totalTime);


        if (musicPlayer != null) {
            musicPlayer.stop();
        }

        songData = getIntent();
        bundle = songData.getExtras();

        songList = bundle.getStringArrayList("songList");
        position = bundle.getInt("position", 0);
        String sN = bundle.getString("songName");
        String aN = bundle.getString("artistName");
        String albumN = bundle.getString("albumName");
        String songPath = bundle.getString("filePath");

        try {
            songName.setText(sN);
            artistName.setText(aN);
            albumName.setText(albumN);

            musicPlayer.setDataSource(songPath);
            musicPlayer.prepare();

            musicPlayer.setVolume(0.5f, 0.5f);
            musicPlayer.setLooping(false);
            seekBar.setMax(musicPlayer.getDuration());
            totTime.setText(createTimeLabel(musicPlayer.getDuration()));
            Thread.sleep(200);
            musicPlayer.start();

        } catch (Exception e) {
            e.printStackTrace();
        }


        pausePlayIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {                                                           // WIP pause mechanic
                if (!MainActivity.musicPlayer.isPlaying()) {
                    pausePlayIcon.setImageResource(android.R.drawable.ic_media_pause);              // continue playing
                    songName.setText(sN);
                    artistName.setText(aN);
                    albumName.setText(albumN);
                    MainActivity.musicPlayer.start();                                               // plays
                } else {
                    pausePlayIcon.setImageResource(android.R.drawable.ic_media_play);               // pauses
                    songName.setText(R.string.paused);
                    artistName.setText("");
                    albumName.setText("");
                    MainActivity.musicPlayer.pause();
                }
            }
        });

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int x = (int) Math.ceil(progress / 1000f);
                if (x == 0 && musicPlayer != null && !musicPlayer.isPlaying()) {
                    clearMusicPlayer();
                    pausePlayIcon.setImageResource(android.R.drawable.ic_media_play);
                    MainActivity.this.seekBar.setProgress(0);
                }

                musicPlayer.seekTo(progress);
                seekBar.setProgress(progress);

            }
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}


        });

        musicPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {                    //do something when the song is finished
            @Override
            public void onCompletion(MediaPlayer mp) {
                pausePlayIcon.setImageResource(android.R.drawable.ic_media_play);                       //For now, pause.  Later setup to play the next song
            }
        });

        new Thread(new Runnable() {
            @Override
            public void run() {
                while (musicPlayer != null) {
                    try {
//                        Log.i("Thread ", "Thread Called");
                        // create new message to send to handler
                        if (musicPlayer.isPlaying()) {
                            Message msg = new Message();
                            msg.what = musicPlayer.getCurrentPosition();
                            handler.sendMessage(msg);
                            Thread.sleep(1000);
                        }
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }).start();
    }

    public void switchToSearchActivity(View view) {
            //also, pause/kill the music player here, maybe?
            musicPlayer.stop();
            Intent intent = new Intent(this, SearchActivity.class);
            startActivity(intent);
    }

    @SuppressLint("HandlerLeak")
    private final Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
//            Log.i("handler ", "handler called");
            int current_position = msg.what;
            seekBar.setProgress(current_position);
            String cTime = createTimeLabel(current_position);
            curTime.setText(cTime);
        }
    };

    private void clearMusicPlayer() {
        musicPlayer.stop();
        musicPlayer.release();
        musicPlayer = null;
    }
    protected void onDestroy() {
        MainActivity.super.onDestroy();
        clearMusicPlayer();
    }

    public String createTimeLabel(int duration) {
        String timeLabel = "";
        int min = duration / 1000 / 60;
        int sec = duration / 1000 % 60;

        timeLabel += min + ":";
        if (sec < 10) timeLabel += "0";
        timeLabel += sec;

        return timeLabel;
    }
}