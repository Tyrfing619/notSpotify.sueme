/*
NotSpotify_Phase5_v2.2
Jordan - Updated splash image, merged Phase5_v1.1 and Phase5_v2.1
 */

package com.example.notspotify_phase5_v1;

import android.content.Intent;
import android.media.MediaPlayer;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.TextView;
import android.annotation.SuppressLint;
import android.os.Handler;
import android.os.Message;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    static MediaPlayer musicPlayer;
    ImageButton pausePlayIcon;
    ImageButton fForward;
    ImageButton prev;
    TextView songName;
    TextView artistName;
    TextView albumName;
    TextView curTime;
    TextView totTime;
    SeekBar seekBar;

    ArrayList<String> songList;
    ArrayList<String> artistList;
    ArrayList<String> albumList;
    ArrayList<String> FPList;

    Intent songData;
    Bundle bundle;
    int position;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        songName = findViewById(R.id.songName);
        artistName = findViewById(R.id.artistName);
        albumName = findViewById(R.id.albumName);
        pausePlayIcon = findViewById(R.id.pause_playButton);
        fForward = findViewById(R.id.fastForward);
        prev = findViewById(R.id.previous);
        seekBar = findViewById(R.id.seekBar);
        curTime = findViewById(R.id.curTime);
        totTime = findViewById(R.id.totalTime);


        if (musicPlayer != null) {
            musicPlayer.stop();
        }
        else {
            musicPlayer = new MediaPlayer();
        }

        songData = getIntent();
        bundle = songData.getExtras();

        songList = bundle.getStringArrayList("songlist");
        artistList = bundle.getStringArrayList("artistlist");
        albumList = bundle.getStringArrayList("albumlist");
        FPList = bundle.getStringArrayList("fplist");


        position = bundle.getInt("position", 0);

        playSong(position);

        pausePlayIcon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {                                                           // WIP pause mechanic
                if (!MainActivity.musicPlayer.isPlaying()) {
                    pausePlayIcon.setImageResource(android.R.drawable.ic_media_pause);              // continue playing
                    songName.setText(songList.get(position));
                    artistName.setText(artistList.get(position));
                    albumName.setText(albumList.get(position));
                    MainActivity.musicPlayer.start();                                               // plays
                } else {
                    pausePlayIcon.setImageResource(android.R.drawable.ic_media_play);               // pauses
                    songName.setText(R.string.paused);
                    artistName.setText("");
                    albumName.setText("");
                    MainActivity.musicPlayer.pause();
                }
            }
        });

        fForward.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetMP();
                if(position < songList.size()-1) { position++; }
                else { position = 0; }
                playSong(position);
            }
        });
        prev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetMP();
                if(position > 0) { position--; }
                else { position = songList.size()-1; }
                playSong(position);
            }
        });

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    musicPlayer.seekTo(progress);
                    seekBar.setProgress(progress);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });

        new Thread(new Runnable() {
            @Override
            public void run() {
                while (musicPlayer != null) {
                    try {
                        Message msg = new Message();
                        msg.what = musicPlayer.getCurrentPosition();
                        handler.sendMessage(msg);
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }).start();

        musicPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                if(position < songList.size()-1) {
                    musicPlayer.stop();
                    position++;
                    playSong(position);
                }
                else {
                    position = 0;
                    playSong(position);
                }
            }
        });
    }

    public void resetMP() {
        if (musicPlayer != null && musicPlayer.isPlaying()) {
            musicPlayer.reset();
        }
    }

    public void playSong(final int position) {
        try {
            songName.setText(songList.get(position));
            artistName.setText(artistList.get(position));
            albumName.setText(albumList.get(position));

            String songPath = FPList.get(position);
            musicPlayer.setDataSource(songPath);
            musicPlayer.prepare();
            musicPlayer.setVolume(0.5f, 0.5f);
            musicPlayer.setLooping(false);
            musicPlayer.seekTo(0);
            seekBar.setProgress(0);
            seekBar.setMax(musicPlayer.getDuration());
            totTime.setText(createTimeLabel(musicPlayer.getDuration()));
            musicPlayer.start();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void switchToSearchActivity(View view) {
        //also, pause/kill the music player here, maybe?
        musicPlayer.stop();
        Intent intent = new Intent(this, SearchActivity.class);
        startActivity(intent);
    }

    @SuppressLint("HandlerLeak")
    private final Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            int current_position = msg.what;
            seekBar.setProgress(current_position);
            String cTime = createTimeLabel(current_position);
            curTime.setText(cTime);
        }
    };

    private void clearMusicPlayer() {
        musicPlayer.stop();
        musicPlayer.release();
        musicPlayer = null;
    }
    protected void onDestroy() {
        MainActivity.super.onDestroy();
        clearMusicPlayer();
    }

    public String createTimeLabel(int duration) {
        String timeLabel = "";
        int min = duration / 1000 / 60;
        int sec = duration / 1000 % 60;

        timeLabel += min + ":";
        if (sec < 10) timeLabel += "0";
        timeLabel += sec;
        return timeLabel;
    }
}